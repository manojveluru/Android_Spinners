package manojveluru.niu.spinners;

public class SpinnerInfo
{
    static public String valueArray[] = {"Choclate Chip", "Sugar,", "Peanut Butter", "Macaron" };

    static public int idArray[] = {R.drawable.ic_launcher_background};
}//end  SpinnerInfo
